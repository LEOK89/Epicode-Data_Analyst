import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

file_poverty_explorer="./poverty-explorer.csv"
df=pd.read_csv(file_poverty_explorer)



# Let's assume you want to save the 'Share below $1 a day' column
column_to_save = df[['Share below $2.15 a day']]

# Save the column to an Excel file
column_to_save.to_excel("output.xlsx", index=False)



describe_results = df.describe()
print(describe_results)
describe_results.to_csv("describe_results.csv", index=False)

# Seleziona i dati per un range di anni specifico
data_range = df[(df['Year'] >= 2018) & (df['Year'] <= 2022)]
print (data_range)

# Seleziono i dati per un singolo paese
#data_country = df[df['Country'] == 'Italy']
#print(data_country)

# Seleziono i dati per più paesi eventualemente 
data_countries = df[df['Country'].isin(['Italy', 'Germany', 'Greece'])]
print(data_countries)


# Calcolo il numero medio di persone in povertà per ogni anno
average_poverty_numbers = df.groupby('Year')[['Number below $1 a day', 'Number below $2.15 a day', 'Number below $3.65 a day',
                                               'Number below $6.85 a day', 'Number below $10 a day', 'Number below $20 a day',
                                                 'Number below $30 a day', 'Number below $40 a day']].mean()

# Creo un nuovo grafico
fig, ax = plt.subplots()

# Imposto il colore di sfondo del grafico su grigio
ax.set_facecolor('gainsboro')

# Trasformo il DataFrame in formato lungo per seaborn
average_poverty_numbers = average_poverty_numbers.reset_index().melt('Year', var_name='Threshold', value_name='Number')

# Creo un grafico a linee con marcatori per ogni soglia
sns.lineplot(data=average_poverty_numbers, x='Year', y='Number', hue='Threshold', style='Threshold', markers='o', palette="viridis", linewidth=1.5, alpha=0.8)

# Modifico il colore dell'anno e dei numeri delle percentuali
ax.tick_params(axis='x', colors='darkcyan')
ax.tick_params(axis='y', colors='darkcyan')

# Modifico il colore del titolo e delle etichette
ax.set_title('Numero di persone in povertà rispetto a diverse soglie di povertà, Mondo, 1990-2019', color='darkcyan')
ax.set_xlabel('Anno', color='darkcyan')
ax.set_ylabel('Numero di persone in povertà', color='darkcyan')

# Aggiungo linee orizzontali per aiutare a leggere il grafico
for y in range(0, int(average_poverty_numbers['Number'].max()), 10000000):  # Sostituisci 20000000 con l'intervallo desiderato
    plt.axhline(y=y, color='darkgrey', linestyle='--', linewidth=0.7)

# Modifico il colore e la trasparenza della legenda
legend = ax.legend(facecolor='gainsboro', edgecolor='gainsboro', framealpha=0.5)
plt.setp(legend.get_texts(), color='darkcyan')

# Cambio il colore dei bordi 
ax.spines['bottom'].set_color('darkcyan')
ax.spines['top'].set_color('darkcyan') 
ax.spines['right'].set_color('darkcyan')
ax.spines['left'].set_color('darkcyan')
fig.patch.set_facecolor('gainsboro')

# Mostra il grafico
plt.show()


