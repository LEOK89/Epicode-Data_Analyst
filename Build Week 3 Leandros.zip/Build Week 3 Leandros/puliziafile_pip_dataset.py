import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

file_pip="./pip_dataset.csv"
df=pd.read_csv(file_pip)
# print(df)

df.drop(columns=['survey_year', 'survey_comparability'], inplace=True)
# Salvo in un nuovo file csv pulito
df.to_csv('pip_dataset_clean.csv', index=False)

"""
# Calcola la media del rapporto di testa per anno
average_headcount = df.groupby('year')['headcount_ratio_international_povline'].mean()

# Crea un grafico a linee
plt.plot(average_headcount.index, average_headcount.values)
plt.xlabel('Anno')
plt.ylabel('Rapporto di testa medio')
plt.title('Andamento nel tempo del rapporto di testa a livello internazionale')
plt.show()"""