import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import seaborn as sns

# Carico i dati 
poverty_thresholds="./povertythresholds.csv"
df = pd.read_csv(poverty_thresholds)

# Calcolo la quota media della popolazione in povertà per ogni anno
average_poverty_share = df.groupby('Year')[['$2.15 a day - Share of population in poverty','$3.65 a day - Share of population in poverty',
                                             '$6.85 a day - Share of population in poverty','$10 a day - Share of population in poverty',
                                             '$20 a day - Share of population in poverty','$30 a day - Share of population in poverty',
                                             '$40 a day - Share of population in poverty']].mean()


# Creo un nuovo grafico
fig, ax = plt.subplots()

# Imposto il colore di sfondo del grafico su grigio
ax.set_facecolor('gainsboro')

# Trasformo il DataFrame in formato lungo per seaborn
average_poverty_share = average_poverty_share.reset_index().melt('Year', var_name='Threshold', value_name='Share')

# Creo un grafico a linee con marcatori per ogni soglia
sns.lineplot(data=average_poverty_share, x='Year', y='Share', hue='Threshold', style='Threshold', markers='o', palette="viridis", linewidth=1.5, alpha=0.8)

# Modifico il colore dell'anno e dei numeri delle percentuali
ax.tick_params(axis='x', colors='darkcyan')
ax.tick_params(axis='y', colors='darkcyan')


# Modifico il colore del titolo e delle etichette
ax.set_title('Percentuale di popolazione in povertà rispetto a diverse soglie di povertà, Mondo, 1990-2019', color='darkcyan')
ax.set_xlabel('Anno', color='darkcyan')
ax.set_ylabel('Percentuale di popolazione in povertà (%)', color='darkcyan')

# Formatto l'asse y come percentuale
fmt = '%.0f%%' # Formato come percentuale senza decimali
yticks = mtick.FormatStrFormatter(fmt)
ax.yaxis.set_major_formatter(yticks)


# Aggiungo linee al 0%, 20%, 40%, 60%, 80% e 100%
plt.axhline(y=0, color='darkgrey', linestyle='--', linewidth=0.7)
plt.axhline(y=20, color='darkgrey', linestyle='--', linewidth=0.7)
plt.axhline(y=40, color='darkgrey', linestyle='--', linewidth=0.7)
plt.axhline(y=60, color='darkgrey', linestyle='--', linewidth=0.7)
plt.axhline(y=80, color='darkgrey', linestyle='--', linewidth=0.7)
plt.axhline(y=100, color='darkgrey', linestyle='--', linewidth=0.7)

# Modifico il colore e la trasparenza della legenda
legend = ax.legend(facecolor='gainsboro', edgecolor='gainsboro', framealpha=0.5)
plt.setp(legend.get_texts(), color='darkcyan')

#camio il coloere dei bordi 
ax.spines['bottom'].set_color('darkcyan')
ax.spines['top'].set_color('darkcyan') 
ax.spines['right'].set_color('darkcyan')
ax.spines['left'].set_color('darkcyan')
fig.patch.set_facecolor('gainsboro')

# Mostra
plt.show()
