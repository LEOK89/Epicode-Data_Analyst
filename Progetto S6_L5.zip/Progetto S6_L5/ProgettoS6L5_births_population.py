import numpy as np
import pandas as pd
from matplotlib import  pyplot as plt
import humanize as h
import seaborn as sns


#Vogliamo trovare il totale delle nascite per capire se influenza la popolazione,
# e cosi da capire se il flusso migratorio influenza nelle nascite per ogni distretto in base alla popolazione e la disoccupazione?

file_nascite="./births.csv"
file_popolazione="./population.csv"

df_nascite=pd.read_csv(file_nascite)
df_popolazione=pd.read_csv(file_popolazione)
df_merge=pd.merge(df_nascite,df_popolazione,on=["Number"])

# Numero di nascite per distretto.
totale_per_distretto = df_merge.groupby("District Name")["Number"].sum()


print(totale_per_distretto)

plt.figure(figsize=(10,6))
totale_per_distretto.plot(kind="bar")
plt.title("Total Number di nascite per District")
plt.xlabel("District Name")
plt.ylabel("Total Number")
plt.show()

