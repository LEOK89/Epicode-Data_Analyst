import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import humanize as h
import seaborn as sns

#1. Vogliamo cercare di capire qualche disretto ha il maggior tasso di disoccupazione?
#2. Calcoliamo il gender gap per i diversi disretti?

file_unemployment="./unemployment.csv"
df_unemployments=pd.read_csv(file_unemployment)
total = df_unemployments["Number"].sum()
df_unemployments["Percentage"] = df_unemployments["Number"] / total * 100

richiesta_lavoro_per_disretto = df_unemployments.groupby("District Name")["Number"].sum().sort_values(ascending=False)
plt.figure(figsize=(10,5))
sns.barplot(x=richiesta_lavoro_per_disretto.index, y=richiesta_lavoro_per_disretto.values)
plt.title("Richiesta lavoro per distretto")
plt.xticks(rotation=90)
plt.show()


richiesta_per_genere = df_unemployments.groupby("Gender")["Number"].sum()
plt.figure(figsize=(10,5))
sns.barplot(x=richiesta_per_genere.index, y=richiesta_per_genere.values)
plt.title("Richiesta lavoro per genere")
plt.show()


