import numpy as np
import pandas as pd
from matplotlib import  pyplot as plt
import humanize as h
import seaborn as sns


#Vogliamo trvare il totale dei immigrati in entrata e in uscita.

file_imm_eta="./immigrants_emigrants_by_age.csv"

df_eta=pd.read_csv(file_imm_eta)


imm_per_eta = df_eta.groupby("Age")["Immigrants"].sum().sort_index(ascending=False)
print(imm_per_eta)
imm_per_eta.plot(kind= 'barh', color='blue')
plt.title("Totale Immigrazione per fascia d'eta")
plt.xlabel('Numero di Immigrati')
plt.ylabel("Fascia d'eta")
plt.show()

imm_per_eta = df_eta.groupby("Age")["Emigrants"].sum().sort_index(ascending=False)
print(imm_per_eta)
imm_per_eta.plot(kind= 'barh', color='blue')
plt.title("Totale Immigrazione per fascia d'eta")
plt.xlabel('Numero di Emmigrati')
plt.ylabel("Fascia d'eta")
plt.show()




