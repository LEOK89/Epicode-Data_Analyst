# Scegliete un dataset a vostro piacere (che abbia almeno un migliaio di righe e 5 colonne)
# e analizzatelo come abbiamo imparato a fare finora: 
# esplorate i dati sia colonna per colonna che in combinazioni di esse e applicate i concetti di statistica appresi nel modulo precedente,
# utilizzando Python. A fine giornata ognuno deve presentare un jupyter notebook pulito 
# (non ci devono essere refusi, il codice deve compilare in ogni cella) che mostri l’analisi fatta,
# compresa di grafici e spiegazioni inerenti.


# Abbiamo scelto un dataset sulla città di Barcellona, che contiente vari daset interni.
# Stiamo partendo l"analisi con il dataset sull"immigrazione per nazionalità.
# Vogliamo creare dei collegamenti con i dataset(immigrazione-nascite),
# per capire l'impatto delle nascite sui vari distretti.



import numpy as np
import pandas as pd
from matplotlib import  pyplot as plt
import humanize as h
import seaborn as sns



file_immigrants_by_nationality="./immigrants_by_nationality.csv"

df_immigrants=pd.read_csv(file_immigrants_by_nationality)



# Troviamo il distretto con il maggior numero di persone ?

district_max_persone = df_immigrants.loc[df_immigrants["Number"].idxmax()]["District Name"]
print("Il disretto con maggior numero di popolazione è:",district_max_persone)

# Distribuzione Temporale Immigrazione ?

flusso_immigrazione = df_immigrants.groupby(["Year","Nationality"])["Number"].sum()
print(flusso_immigrazione)

# Voglio vedere l"immigrazione per ogni anno e da che paese vengono?
#Anno 2015
flusso_2015 = flusso_immigrazione.loc[2015]

plt.bar( flusso_2015.index,flusso_2015.values)
plt.xlabel("Nationality")
plt.ylabel("Number")
plt.title("Flusso nell anno 2015")
plt.show()

#Anno 2016
flusso_2016 = flusso_immigrazione.loc[2016]

plt.bar( flusso_2016.index,flusso_2016.values)
plt.xlabel("Nationality")
plt.ylabel("Number")
plt.title("Flusso nell anno 2016")
plt.show()

#Anno 2017
flusso_2017 = flusso_immigrazione.loc[2017]

plt.bar( flusso_2017.index,flusso_2017.values)
plt.xlabel("Nationality")
plt.ylabel("Number")
plt.title("Flusso nell anno 2017")
plt.show()

# Come è cambiato il numero totale di immigrati nel corso degli anni?

immigrati_per_anno = df_immigrants.groupby("Year")["Number"].sum()
plt.figure(figsize=(10,5))
sns.lineplot(data=immigrati_per_anno)
plt.title("Numero totale di immigrati per anno")
plt.show()

# Quali quartieri hanno ricevuto il maggior numero di immigrati?

Immigrati_per_distretto = df_immigrants.groupby("District Name")["Number"].sum()
plt.figure(figsize=(10,10))
# Creiamo un grafico a torta
Immigrati_per_distretto.plot(kind='pie', autopct='%1.2f%%', colors=sns.color_palette('pastel'))
plt.title("Percentule di distribuzione per ogni distretto")
# Mostrare solo il grafico a torta senza etichette sull'asse y
plt.ylabel('')
plt.show()

# Quali sono le nazionalità più comuni tra gli immigrati?

nazionalità_comuni = df_immigrants.groupby("Nationality")["Number"].sum().sort_values(ascending=False)
plt.figure(figsize=(10,5))
sns.barplot(x=nazionalità_comuni.index[:10], y=nazionalità_comuni.values[:10])  # Solo le prime 10 nazionalità
plt.title("Le 10 nazionalità più comuni tra gli immigrati")
plt.xticks(rotation=90)
plt.show()


# la seconda domanda 
# Flusso di immigrazione raggruppato per anno e nazionalità
flusso_immigrazione = df_immigrants.groupby(["Year", "Nationality"])["Number"].sum().sort_values(ascending=False)
# Creazione della griglia di subplots
fig, axs = plt.subplots(3, 1, figsize=(10, 15), sharex=True)

for i, anno in enumerate([2015, 2016, 2017]):
    flusso_anno = flusso_immigrazione.loc[anno].head(10)
    axs[i].bar(flusso_anno.index, flusso_anno.values, label=f'Anno {anno}', color=f'C{i}')
    axs[i].set_title(f"Flusso nell'anno {anno}")
    axs[i].set_xlabel('Nationalità')
    axs[i].set_ylabel('Numero di Immigrati')
# Aggiungi una legenda generale
fig.legend(loc='upper right', bbox_to_anchor=(0.85, 0.9))
# Aggiungi titolo e mostra il grafico
fig.suptitle("Flusso di immigrazione per anno e nazionalità (Top 10)", fontsize=16)
plt.show()

