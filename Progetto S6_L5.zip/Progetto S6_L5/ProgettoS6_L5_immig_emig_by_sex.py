import numpy as np
import pandas as pd
from matplotlib import  pyplot as plt
import humanize as h
import seaborn as sns


#Vogliamo trvare il totale dei immigrati in base al genere.

file_imm_sex="./immigrants_emigrants_by_sex.csv"

df_sex=pd.read_csv(file_imm_sex)

imm_per_sex = df_sex.groupby("Gender")["Immigrants"].sum().sort_index(ascending=False)
print(imm_per_sex)
imm_per_sex.plot(kind= 'barh', color='blue')
plt.title("Totale Immigrazione per genere")
plt.xlabel('Numero di Immigrati')
plt.ylabel("Genere")
plt.show()