import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

#Carico il file comuni csv in un DF
file_name_comuni="./covid19_comuni_raw.csv"
df_comuni=pd.read_csv(file_name_comuni)

#Facciamo pulizia del file comuni

df_comuni = df_comuni.drop(df_comuni.columns[0], axis=1)
df_comuni = pd.read_csv(file_name_comuni,delimiter=';',skiprows=7).iloc[:-1]
df_comuni = df_comuni.drop(['Unnamed: 1'],axis=1)
df_comuni= df_comuni.dropna(how='all')
df_comuni = df_comuni.drop_duplicates()
df_comuni['Regione'] =df_comuni['Regione'].str.title()
df_comuni['Popolazione2011'] = df_comuni['Popolazione2011'].astype(int)
#Salvo il nuovo file pulito 
df_comuni.to_csv("covid19_comuni_cleaned.csv",index=False)
print(df_comuni)


#Carico il file provincia csv in un DF
file_name_province="./covid19_province_raw.csv"
df_province=pd.read_csv(file_name_province)

#Puliamo il file provincia
df_province = df_province.drop(df_province.columns[0], axis=1)
df_province = df_province.dropna(how='all')
df_province = df_province.drop_duplicates()
df_province['Date'] = pd.to_datetime(df_province['Date'])
df_province['Date'] = df_province['Date'].dt.date
df_province["TotalPositiveCases"]=df_province['TotalPositiveCases'].astype(int)

#Salvo il nuovo file pulito 
df_province.to_csv("covid19_province_cleaned.csv",index=False)
print(df_province)


#Carico il file regioni csv in un DF
file_name_region="./covid19_region_raw.csv"
df_region=pd.read_csv(file_name_region)

#Puliamo il file regioni
df_region = df_region.drop(df_region.columns[0], axis=1)
df_region = df_region.dropna(how='all')
df_region = df_region.drop_duplicates()
df_region['Date'] = pd.to_datetime(df_region['Date'])
df_region['Date'] = df_region['Date'].dt.date
df_region=df_region.fillna(0)
df_region["TotalPositiveCases"]=df_region['TotalPositiveCases'].astype(int)
df_region['TestsPerformed'] = df_region['TestsPerformed'].astype(int)

#Salvo il nuovo file pulito 
df_region.to_csv("covid19_region_cleaned.csv",index=False)
print(df_region)

