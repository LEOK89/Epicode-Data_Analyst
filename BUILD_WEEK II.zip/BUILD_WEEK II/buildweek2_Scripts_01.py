import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

#Carico i DataFrame con il file_csv puliti.
clean_dfcomuni=pd.read_csv("./covid19_comuni_cleaned.csv")
clean_dfprovince=pd.read_csv("./covid19_province_cleaned.csv")
clean_dfregion=pd.read_csv("./covid19_region_cleaned.csv")

#  Query da eseguire ai vari dataset.
#0- Describe regioni che ci rimanda i primi dati sommari.
print(clean_dfregion.describe())
x=clean_dfregion.describe()
x.to_csv("describe.csv")


# 1- È stato calcolato il totale dei deceduti e dei guariti per ogni regione. 

# Filtra il DataFrame per la data '2020-12-06'
clean_dfregion['Date'] = pd.to_datetime(clean_dfregion['Date'])
df_selected_date = clean_dfregion[clean_dfregion['Date'] == '2020-12-06'].reset_index()
# Raggruppa per regione e calcola il totale dei decessi e dei guariti
group_by_region = df_selected_date.groupby("RegionName").agg({"Deaths":"sum", "Recovered":"sum"}).reset_index()
# Ordina i dati per numero totale di morti in ordine decrescente
group_by_region = group_by_region.sort_values(by='Deaths', ascending=False)
print(group_by_region[["RegionName","Deaths","Recovered"]])
# Plot dei morti e guariti per regione
plt.figure(figsize=(10, 8))  # Aumento delle dimensioni del grafico
bar_height = 0.35
index = range(len(group_by_region['RegionName']))
bars1 = plt.barh(index, group_by_region['Deaths'], bar_height, label='Morti')
bars2 = plt.barh([i + bar_height for i in index], group_by_region['Recovered'], bar_height, label='Guariti')
plt.ylabel('Regione')
plt.xlabel('Indice')
plt.title('Tot Guariti e Deceduti per ogni Regione (Data: 2020-12-06)')
# Inverti l'ordine degli elementi sull'asse y
plt.gca().invert_yaxis()
plt.yticks([i + bar_height / 2 for i in index], group_by_region['RegionName'])
plt.legend(loc='lower right')
plt.show()


# 2- Attraverso un grafico a torta, è stata mostrata la distribuzione percentuale di pazienti ospedalizzati,
# in terapia intensiva e in isolamento domiciliare rispetto al totale dei casi positivi.

#clean_dfregion['Date'] = pd.to_datetime(clean_dfregion['Date'])
df_selected_date = clean_dfregion[clean_dfregion['Date'] == '2020-12-06'].reset_index()
df_selected = df_selected_date[['HospitalizedPatients','IntensiveCarePatients','HomeConfinement']]
totals = df_selected.sum()
# Grafico a torta corrispondente
labels = ['Ricoverati', 'Terapia Intensiva', 'Isolamento']
sizes = totals.values
colors = ['lightblue', 'lightcoral', 'lightgreen']
explode = (0.4, 0.6, 0) 
plt.figure(figsize=(8, 6))
plt.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', startangle=140, colors=colors)
plt.axis('equal')  
plt.title('Distribuzione dei Casi COVID-19')
plt.show()

# 3. Assegnazione dei casi positivi totali a ciascun tipo di terapia-stagionali

#clean_dfregion['Date'] = pd.to_datetime(clean_dfregion['Date'])
clean_dfregion.set_index('Date', inplace=True)
# Calcolo dei totali
OspedalizzatiTotITA = clean_dfregion["HospitalizedPatients"].sum()
TerapiaIntensivaTotITA = clean_dfregion["IntensiveCarePatients"].sum()
ConfinatiACasaTotITA =clean_dfregion["HomeConfinement"].sum()
# Calcolo dei totali stagionali
OspedalizzatiStagionaliITA = clean_dfregion.resample("QE")["HospitalizedPatients"].mean()
TerapiaIntensivaStagionaliITA = clean_dfregion.resample("QE")["IntensiveCarePatients"].mean()
ConfinatiACasaStagionaliITA = clean_dfregion.resample("QE")["HomeConfinement"].mean()

# Creazione di un DataFrame per i totali
PazientiPositivi = pd.DataFrame({
    'Ospedalizzati': [OspedalizzatiTotITA],
    'TerapiaIntensiva': [TerapiaIntensivaTotITA],
    'Isolamento domiciliare': [ConfinatiACasaTotITA]
}, index=['Total'])
# Creazione di un DataFrame per i totali stagionali
PazientiPositiviStagionali = pd.DataFrame({
    'Ospedalizzati': OspedalizzatiStagionaliITA,
    'Terapia Intensiva': TerapiaIntensivaStagionaliITA,
    'Isolamento domiciliare': ConfinatiACasaStagionaliITA
})

# Grafico a torta corrispondente
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2,figsize=(10, 8))
fig.suptitle('Distribuzione Stagionale dei Casi COVID-19', fontsize=16, fontweight='bold')

def annotate_pie(ax, labels, sizes):
    ax.pie(sizes, labels=labels,explode=(0.1, 0.1, 0.1), autopct='%1.1f%%', startangle=140, colors=['lightblue', 'lightcoral', 'lightgreen'])
   
annotate_pie(ax1, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[0])
ax1.set_title('Trimestre Invernale')
annotate_pie(ax2, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[1])
ax2.set_title('Trimestre Primaverile')
annotate_pie(ax3, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[2])
ax3.set_title('Trimestre Estivo')
annotate_pie(ax4, PazientiPositiviStagionali.columns, PazientiPositiviStagionali.iloc[3])
ax4.set_title('Trimestre Autunnale')

#total_text = f'Totale Casi Positivi: {OspedalizzatiTotITA}'
#fig.text(0.5, 0.01, total_text, ha='center', va='center', fontsize=12, color='black')

fig.legend(labels=PazientiPositiviStagionali.columns, loc='upper right')
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()

# 4. Andamento grafico nuovi casi positivi nel tempo 
sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))
clean_dfregion.groupby('Date')['NewPositiveCases'].sum().plot(marker='.', linestyle='-', color='r', label='Nuovi Casi Positivi')
plt.title('Andamento dei Nuovi Casi Positivi', fontsize=16)
plt.xlabel('Data', fontsize=12)
plt.ylabel('Nuovi Casi Positivi', fontsize=12)
plt.legend()
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

# 5- Calcola il tasso di guarigione  e il tasso di mortalità nel tempo
# Qual è il tasso di recupero (numero di casi recuperati / casi positivi totali) nel tempo?
clean_dfregion['RecoveryRate'] = clean_dfregion['Recovered'] / clean_dfregion['TotalPositiveCases']
recovery_rate=clean_dfregion.groupby('Date')['RecoveryRate'].mean()

# Qual è il tasso di mortalità (numero di morti / casi positivi totali) nel tempo?
clean_dfregion['MortalityRate'] = clean_dfregion['Deaths'] / clean_dfregion['TotalPositiveCases']
mortality_rate=clean_dfregion.groupby('Date')['MortalityRate'].mean()

# Creiamo il grafico
plt.figure(figsize=(10, 6))
# Barre per il tasso di guarigione
plt.bar(recovery_rate.index, recovery_rate, label='Tasso di guarigione', color='lightgreen')
# Barre per il tasso di mortalità
plt.bar(mortality_rate.index, mortality_rate, label='Tasso di mortalità', color='salmon')
# Titolo e etichette degli assi
plt.title('Tasso di guarigione e tasso di mortalità nel tempo')
plt.xlabel('Data')
plt.ylabel('Tasso')
# Aggiungi una legenda
plt.legend()
# Ruota le etichette sull'asse x per una migliore leggibilità
plt.xticks(rotation=45)
# Mostra il grafico
plt.tight_layout()
plt.show()

# 6. Le prime 15 province con più positivi:
# Filtra il DataFrame per la data '2020-12-06'
clean_dfprovince['Date'] = pd.to_datetime(clean_dfprovince['Date'])
province_selected_date = clean_dfprovince[clean_dfprovince['Date'] == '2020-12-06'].reset_index()

# Raggruppa i dati per ProvinceName e calcola la somma dei TotalPositiveCases per ciascuna provincia
province_cases = province_selected_date.groupby('ProvinceName')['TotalPositiveCases'].sum()

# Ordina le province in base al numero totale di casi positivi in ordine decrescente
province_cases_sorted = province_cases.sort_values(ascending=False)

# Seleziona le prime 15 province con il numero più alto di casi positivi
top_15_province = province_cases_sorted.head(15)
print(top_15_province)
# Crea il grafico
plt.figure(figsize=(10, 6))

# Plot delle prime 15 clean_dfprovince con il numero più alto di casi positivi
top_15_province.plot(kind='bar', color='skyblue')

# Titolo e etichette degli assi
plt.title('Top 10 Province con il numero più alto di casi positivi ')
plt.xlabel('Province')
plt.ylabel('Totale casi positivi')

# Mostra il grafico
plt.xticks(rotation=90)  # Ruota le etichette sull'asse x per una migliore leggibilità
plt.tight_layout()
plt.show()

# 7. Variazione dei nuovi casi per la regione Lombardia
lombardia_data = clean_dfregion[clean_dfregion['RegionName'] == 'Lombardia'].reset_index()
#lombardia_data['Date'] = pd.to_datetime(lombardia_data['Date'])
weekly_new_cases = lombardia_data.groupby(pd.Grouper(key='Date', freq='W-Mon'))['NewPositiveCases'].sum().reset_index()

# Grafico corrispondente
plt.figure(figsize=(12, 8))
plt.plot(weekly_new_cases['Date'], weekly_new_cases['NewPositiveCases'], marker='o', markersize=5, color='blue', label='Nuovi casi settimanali')
plt.title('Variazioni Settimanali dei Nuovi Casi nella Regione Lombardia')
plt.xlabel('Data')
plt.ylabel('Nuovi casi')
plt.xticks(rotation=45)
plt.grid(True)
plt.legend()
plt.tight_layout()

# Aggiungi annotazioni, ad esempio la data con il picco massimo di nuovi casi
peak_date = weekly_new_cases.loc[weekly_new_cases['NewPositiveCases'].idxmax(), 'Date']
peak_cases = weekly_new_cases['NewPositiveCases'].max()
plt.annotate(f'Picco: {peak_cases} casi\n{peak_date.strftime("%d-%m-%Y")}',
             xy=(peak_date, peak_cases), xytext=(peak_date, peak_cases + 100),
             arrowprops=dict(facecolor='red', arrowstyle='->'),
             fontsize=10, color='red')
plt.show()




# 8. Analizziamo la somma dei nuovi casi per ogni provincia della Lombardia
# Filtro i dati solo per la regione Lombardia e rimuovo le province indesiderate
desired_provinces = ['Bergamo', 'Brescia', 'Como', 'Cremona', 'Lecco', 'Lodi', 'Mantova',
                     'Milano', 'Monza e della Brianza', 'Pavia', 'Sondrio', 'Varese']
lombardia_data_filtered = clean_dfprovince[clean_dfprovince['ProvinceName'].isin(desired_provinces)]


lombardia_data_filtered['Date'] = pd.to_datetime(lombardia_data_filtered['Date'])
# Raggruppo i dati per provincia e settimana, calcolando la somma dei nuovi casi per ogni settimana
lombardia_data_filtered = clean_dfprovince[clean_dfprovince['ProvinceName'].isin(desired_provinces)].copy()

weekly_new_cases_by_province = lombardia_data_filtered.groupby(['ProvinceName', pd.Grouper(key='Date', freq='W-Mon')])['TotalPositiveCases'].sum().reset_index()
# Grafico corrispondente per visualizzare le variazioni settimanali dei nuovi casi per ogni provincia
plt.figure(figsize=(12, 8))
for province, data in weekly_new_cases_by_province.groupby('ProvinceName'):
    plt.plot(data['Date'], data['TotalPositiveCases'], label=province, marker='o', markersize=5)
plt.legend()
plt.title('Variazioni settimanali dei nuovi casi per provincia nella regione Lombardia')
plt.xlabel('Settimana')
plt.ylabel('Nuovi casi')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

####### 9. Percentuale dei morti rispetto al totale dei casi positivi in Italia
# Filtra il DataFrame per la data '2020-12-06'
#region['Date'] = pd.to_datetime(region['Date'])
#df_selected_date = region[region['Date'] == '2020-12-06']

# Calcola la percentuale totale di morti rispetto ai casi positivi per la data selezionata
total_death_percentage = (df_selected_date['Deaths'].sum() / df_selected_date['TotalPositiveCases'].sum()) * 100

# Crea un DataFrame con i valori per il grafico a torta
data = {'Morti': total_death_percentage, 'Guariti': 100 - total_death_percentage}
df = pd.DataFrame(data, index=['Percentuale'])

# Crea il grafico a torta con uno stile migliorato
plt.figure(figsize=(8, 8))
colors = ['lightcoral', 'lightgreen']
explode = (0.3, 0)  # Evidenzia il segmento relativo ai decessi
plt.pie(df.iloc[0], labels=df.columns, autopct='%1.1f%%', colors=colors, explode=explode, shadow=True, startangle=140)
plt.title('Percentuale totale di morti rispetto al totale dei guariti', fontsize=16)
plt.axis('equal')  # Garantisce che il grafico sia circolare
plt.show()



#10-- Correlazione tra variabili nel tempo
data_for_correlation = clean_dfregion[['TestsPerformed', 'NewPositiveCases', 'HospitalizedPatients', 'Recovered', 'Deaths']].reset_index()
# Calcola la matrice di correlazione
correlation_matrix = data_for_correlation.corr()
# Crea un heatmap della matrice di correlazione
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
# Impostazioni aggiuntive
plt.title('Correlazione tra Variabili nel Tempo')
plt.show()


# 11-  Abbiamo ottenuto i dati della popolazione anno 2020.
# Carichiamo il file EXCEL in un DataFrame
popolazione = pd.read_excel('Popolazione2020.xlsx',
                           skiprows=8,
                           names=["Regioni", "Maschi", "Femmine", "Totale"],
                           usecols=[0, 2, 3, 4]).iloc[:-1]

#print(popolazione)
popolazione[['Maschi', 'Femmine', 'Totale']] = popolazione[['Maschi', 'Femmine', 'Totale']].astype(int)
print(popolazione)
#CALCOLO IL TOTALE DELLA POPOLAZIONE IN ITALIA DIVISA PER SESSO
totale_popolazione = popolazione["Totale"].sum()
totale_maschi = popolazione["Maschi"].sum()
totale_femmine = popolazione["Femmine"].sum()
print("Il totale della popolazione italiana all'inizio del 2020 è: ", totale_popolazione)
print("Il totale della popolazione italiana maschile è: ", totale_maschi)
print("Il totale della popolazione italiana femminile è: ", totale_femmine)

# Creazione di un grafico a torta
plt.figure(figsize=(8, 8))
sizes = [totale_maschi, totale_femmine]
labels = ['Maschi', 'Femmine']
colors = ['lightblue', 'pink']
explode = (0.1, 0)  # Esplosione della fetta 'Maschi'
plt.pie(sizes, labels=labels, colors=colors, explode=explode, autopct='%1.1f%%', shadow=True, startangle=140)
plt.title('Totale della popolazione italiana per sesso (2020)', fontsize=16)
plt.axis('equal')  # Equalizza gli assi per rendere il grafico a torta circolare
total_text = f'Totale \n popolazione: \n {totale_popolazione}'
plt.figtext(0.9, 0.5, total_text, ha='center', va='center', fontsize=12, color='black')
plt.show()
popolazione.to_csv("Popolazione Italiana nell'anno 2020.csv")

totale_popolazione = popolazione["Totale"].sum()
# Filtra il DataFrame regioni per la data '2020-12-06'
#clean_dfregion['Date'] = pd.to_datetime(clean_dfregion['Date'])
totale_morti_regione_date = clean_dfregion[clean_dfregion['Date'] == '2020-12-06']
totale_morti = totale_morti_regione_date['Deaths'].sum()
# Calcola la differenza tra la popolazione totale all'inizio del 2020 e il totale dei morti per COVID-19
variazione_popol_causa_morti = totale_popolazione - totale_morti
# Crea un dizionario con i dati per il grafico a barre
data = {'Popolazione inizio 2020': totale_popolazione, 'Popolazione a causa delle morti': variazione_popol_causa_morti}
# Creazione di un grafico a barre
plt.figure(figsize=(10, 6))
bars = plt.bar(data.keys(), data.values(), color=['lightblue', 'lightcoral'])
plt.title('Variazione della popolazione a causa delle morti per COVID-19 nel 2020', fontsize=16)
plt.ylabel('Popolazione italiana')
# Aggiungi il valore numerico all'interno delle barre
for bar in bars:
   height = bar.get_height()
   plt.text(bar.get_x() + bar.get_width() / 2, height, str(int(height)), ha='center', va='bottom', fontweight='bold')
tasso_mortalita = (totale_morti / totale_popolazione) * 100
total_text = f'Tasso di mortalità: {tasso_mortalita:.2f}%'
plt.figtext(0.7, 0.5, total_text, ha='center', va='center', fontsize=10, color='red')
plt.show()


#12: Calcolo variazione popolazione divisa per regione da inizio 2020 a fine 2020 a causa delle morti per Covid

# Rimuovi spazi aggiuntivi nei nomi delle regioni
popolazione['Regioni'] = popolazione['Regioni'].str.strip()
# Sostituisce i nomi di alcune regioni della colonna Regioni nel file popolazione
popolazione['Regioni'] = popolazione['Regioni'].replace({'Trentino Alto Adige / Südtirol': 'Trentino Alto Adige',
                                                        "Valle d'Aosta / Vallée d'Aoste": "Valle d'Aosta",
                                                        'Friuli-Venezia Giulia': 'Friuli Venezia Giulia'})
# Sostituisce i nomi di alcune regioni della colonna Regioni nel file regioni
clean_dfregion['RegionName'] = clean_dfregion['RegionName'].replace({'P.A. Bolzano': 'Trentino Alto Adige',
                                                      "P.A. Trento": "Trentino Alto Adige"})
# Filtra il DataFrame regioni per la data '2020-12-06'
clean_dfregion['Date'] = pd.to_datetime(clean_dfregion['Date'])
totale_morti_regione_date = clean_dfregion[clean_dfregion['Date'] == '2020-12-06'].reset_index()
# Creare un dizionario vuoto per contenere i dati
data = {'Regioni': [], 'Popolazione inizio 2020': [], 'Popolazione a causa delle morti': []}
# Iterare sul DataFrame 'popolazione' per ottenere le informazioni di ogni regione
for idx, reg in popolazione.iterrows():
   regione = reg['Regioni']
   tot_popol_regione = reg['Totale']
   # Ottieni il totale dei morti per la regione corrispondente alla data specifica
   tot_morti_regione = totale_morti_regione_date[totale_morti_regione_date['RegionName'] == regione.strip()]['Deaths'].values[0]
  
   # Aggiungi i dati al dizionario
   data['Regioni'].append(regione)
   data['Popolazione inizio 2020'].append(tot_popol_regione)
   data['Popolazione a causa delle morti'].append(tot_popol_regione - tot_morti_regione)
# Creazione di un DataFrame dai dati
df_data = pd.DataFrame(data)
# Creazione di un grafico a barre per ogni regione con la variazione percentuale
plt.figure(figsize=(14, 8))
bar_width = 0.35
bar1 = plt.bar(df_data.index, df_data['Popolazione inizio 2020'], width=bar_width, label='Popolazione inizio 2020', color='lightblue')
bar2 = plt.bar(df_data.index + bar_width, df_data['Popolazione a causa delle morti'], width=bar_width, label='Popolazione a causa delle morti', color='lightcoral')
# Aggiungi la variazione percentuale come testo nel grafico
for i, (pop_inizio, pop_morti) in enumerate(zip(df_data['Popolazione inizio 2020'], df_data['Popolazione a causa delle morti'])):
   plt.text(i + bar_width / 2, max(pop_inizio, pop_morti) + 10, f'{((pop_morti - pop_inizio) / pop_inizio) * 100:.2f}%', ha='center', va='center', fontsize=10, color='black')
plt.title('Variazione della popolazione a causa delle morti per COVID-19 il 2020-12-06 per ogni regione', fontsize=16)
plt.xlabel('Regioni')
plt.ylabel('Variazione della popolazione')
plt.xticks(df_data.index + bar_width/2, df_data['Regioni'], rotation=45, ha='right', rotation_mode='anchor')  # Posiziona le etichette sull'asse x
plt.legend()
plt.tight_layout() 
plt.show()





