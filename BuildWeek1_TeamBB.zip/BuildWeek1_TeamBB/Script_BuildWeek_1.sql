                           -- Esercizio BuildWeek_1
-- Immaginate di lavorare per un'azienda di e-commerce che vende prodotti di varie categorie.
 -- Il vostro compito è eseguire un'analisi dei dati per ottenere informazioni utili per la crescita e la gestione del business.
 -- Il dataset fornito include informazioni sulle transazioni, i prodotti, i clienti e le spedizioni.
 
-- N°1 Trova il totale delle vendite per ogni mese.
select month(DataTransazione) as MESE,
sum(QuantitaAcquistata) as TotaleVenditeMese from transazioni
group by Month(DataTransazione)
order by Month(DataTransazione) 
;

-- N°2 Identifica i tre prodotti più venduti e la loro quantità venduta.
select NomeProdotto, t.ProdottoID,
sum(QuantitaAcquistata) AS NumeriAcquisti from transazioni t
join prodotti p on p.ProdottoID = t.ProdottoID
group by t.ProdottoID
order by NumeriAcquisti desc limit 3;

-- N°3 Trova il cliente che ha effettuato il maggior numero di acquisti.
select t.ClienteID,c.NomeCliente, sum(QuantitaAcquistata) as NumeriAcquisti
from transazioni t
join clienti c on t.ClienteID = c.ClienteID
group by c.ClienteID,c.NomeCliente
order by NumeriAcquisti  desc limit 1 ;

-- N°4 Calcola il valore medio di ogni transazione.
-- Vogliamo il valore totale degli ordini effettuati per trovare il valore medio della transazione
-- (Valore_tot/num_transazioni) AOV = ricavi totali / numero di ordini.
select month(DataTransazione),p.categoria,
sum(QuantitaAcquistata*Prezzo)/count(t.ProdottoID) as ValoreMedio
from transazioni t
join prodotti p on p.ProdottoID = t.ProdottoID
group by Month(DataTransazione),p.Categoria;



-- N°5 Determina la categoria di prodotto con il maggior numero di vendite.
select p.Categoria,sum(QuantitaAcquistata) as MaggiorNumeroVendite 
from transazioni t
join prodotti p on p.ProdottoID =t.ProdottoID
group by p.Categoria
order by MaggiorNumeroVendite
desc limit  1;

-- N°6 Identifica il cliente con il maggior valore totale di acquisti.
select t.ClienteID, sum(t.QuantitaAcquistata*p.Prezzo) as MaxTotAcquisti
from transazioni t
join prodotti p on p.ProdottoID =t.ProdottoID
group by t.ClienteID
order by MaxTotAcquisti desc limit 1 ;

-- N°7 Calcola la percentuale di spedizioni con "Consegna Riuscita".
SELECT 
(count( case when StatusConsegna='Consegna Riuscita'  then 1 end )/count(StatusConsegna)) 
as Percentuale_Consegna_Riuscita
from spedizioni;
 

-- N°8 Trova il prodotto con la recensione media più alta.
select ProductID, avg(Rating) as MediaRecensione, count(Rating) as NumeroRecensioni
from ratings r
join prodotti p  on p.ProdottoID=r.ProductID
group by ProdottoID
order by  MediaRecensione desc ,NumeroRecensioni
desc  limit 1;

-- N° 9 Calcola la variazione percentuale nelle vendite rispetto al mese precedente.
select month(DataTransazione) as Mese, 
	year(DataTransazione) as Anno,
SUM(QuantitaAcquistata*Prezzo) AS TotaleVenditeMese,
((SUM(QuantitaAcquistata*Prezzo) - LAG(SUM(QuantitaAcquistata*Prezzo), 1, 0) OVER(ORDER BY MONTH(DataTransazione))) / LAG(SUM(QuantitaAcquistata*Prezzo), 1, 0) OVER(ORDER BY MONTH(DataTransazione))) AS VariazioneVenditePercentuale
FROM transazioni t
join prodotti p on p.ProdottoID =t.ProdottoID
GROUP BY 
MONTH(DataTransazione), 
year(DataTransazione);

SELECT 
    MESE,
    SommaVendite,
    LAG (SommaVendite) OVER (ORDER BY MESE) AS SommaMesePrima,
    (SommaVendite/LAG (SommaVendite) OVER (ORDER BY MESE)-1)*100 AS VARIAZIONEPERC
FROM (
    SELECT month(DataTransazione) AS MESE,sum(Prezzo) AS SommaVendite
    FROM prodotti
    JOIN transazioni ON prodotti.ProdottoID = transazioni.ProdottoID
    GROUP BY month(DataTransazione)
    order by MESE) TOTVENDITE;
    
    
-- N° 10 Determina la quantità media disponibile per categoria di prodotto.
select Categoria, avg(QuantitaDisponibile-QuantitaAcquistata) as QuantitaMediaDisponibile
from prodotti p
join transazioni t on t.ProdottoID=p.ProdottoID
group by Categoria ;

-- N° 11 Trova il metodo di spedizione più utilizzato.
-- Dove dobbiamo fare il calcolo sulle spedizioni o sulle transazioni ? 
-- Non tornano i numeri 500 trans-5000spedi
select MetodoSpedizione, count(MetodoSpedizione) as metodo_spedizione_piu_utilizzato
from spedizioni
group by MetodoSpedizione
order by metodo_spedizione_piu_utilizzato
desc limit 1;

-- N°12 Calcola il numero medio di clienti registrati al mese.
select avg(numero_clienti_registrazioni_mensili) as NumeroRegistrazioneMedioMensile
from(
SELECT YEAR(dataregistrazione) AS anno, MONTH(dataregistrazione) AS mese, COUNT(ClienteID) AS numero_clienti_registrazioni_mensili
FROM clienti
GROUP BY YEAR(dataregistrazione), MONTH(dataregistrazione)) conteggio_mensile;

-- N°13 Identifica i prodotti con una quantità disponibile inferiore alla media.

-- 1 Versione senza tener conto le transazioni degli ordini
/*
select NomeProdotto,QuantitaDisponibile
from prodotti 
where QuantitaDisponibile < (select avg(QuantitaDisponibile) from prodotti);
*/
-- 2 Versione tenendo conto gli ordini

WITH QuantitaDopoTransazioni AS (
    SELECT prodotti.NomeProdotto, 
           (prodotti.QuantitaDisponibile - COALESCE(SUM(transazioni.QuantitaAcquistata), 0)) AS QuantitaDopoTransazioni
    FROM prodotti 
    LEFT JOIN transazioni ON prodotti.ProdottoID = transazioni.ProdottoID
    GROUP BY prodotti.ProdottoID, prodotti.QuantitaDisponibile
)
SELECT NomeProdotto, QuantitaDopoTransazioni
FROM QuantitaDopoTransazioni
WHERE QuantitaDopoTransazioni < (SELECT AVG(QuantitaDopoTransazioni) FROM QuantitaDopoTransazioni)
order by QuantitaDopoTransazioni ;

-- N°14 Per ogni cliente, elenca i prodotti acquistati e il totale speso
select clienti.ClienteID, prodotti.ProdottoID, SUM(transazioni.QuantitaAcquistata * prodotti.Prezzo) AS TotaleAcquisti
FROM clienti
JOIN transazioni ON clienti.ClienteID = transazioni.ClienteID
JOIN prodotti ON transazioni.ProdottoID = prodotti.ProdottoID
GROUP BY clienti.ClienteID, prodotti.ProdottoID;

-- N°15 Identifica il mese con il maggior importo totale delle vendite.
WITH VenditeMensili AS (
    SELECT DATE_FORMAT(transazioni.DataTransazione, '%m') AS Mese, 
           SUM(prodotti.Prezzo * transazioni.QuantitaAcquistata) AS TotaleVendite
    FROM transazioni
    JOIN prodotti ON transazioni.ProdottoID = prodotti.ProdottoID
    GROUP BY DATE_FORMAT(transazioni.DataTransazione, '%m')
)

SELECT Mese, TotaleVendite
FROM VenditeMensili
WHERE TotaleVendite = (SELECT MAX(TotaleVendite) FROM VenditeMensili);

-- N°16 Trova la quantità totale di prodotti disponibili in magazzino.
WITH QuantitaDopoOrdini AS (
    SELECT p.ProdottoID, 
           (p.QuantitaDisponibile - COALESCE(SUM(t.QuantitaAcquistata), 0)) AS QuantitaDisponibileDopoOrdini
    FROM prodotti p 
    LEFT JOIN transazioni t ON p.ProdottoID = t.ProdottoID
    GROUP BY p.ProdottoID, p.QuantitaDisponibile
)

SELECT SUM(QuantitaDisponibileDopoOrdini) AS Quantita_Tot_Disponibile_Dopo_Ordini
FROM QuantitaDopoOrdini
ORDER BY Quantita_Tot_Disponibile_Dopo_Ordini ;

-- N°17 Identifica i clienti che non hanno effettuato alcun acquisto.
SELECT ClienteID, NomeCliente
FROM clienti
WHERE ClienteID NOT IN (
    SELECT DISTINCT ClienteID
    FROM transazioni
    WHERE ClienteID IS NOT NULL
);

-- N°18 Calcola il totale delle vendite per ogni anno.
select year(DataTransazione),
sum(QuantitaAcquistata) as Quantita_Vendute_Annuali,
sum(QuantitaAcquistata*Prezzo) as Importo_Totale_Annuali
from transazioni t
join prodotti p on p.ProdottoID=t.ProdottoID
group by year(DataTransazione)
order by year(DataTransazione);

-- N°19 Trova la percentuale di spedizioni con "In Consegna" rispetto al totale.
SELECT 
(count( case when StatusConsegna='In Consegna'  then 1 end )/count(StatusConsegna)) 
as Percentuale_In_Consegna
from spedizioni;

                                       -- DOMANDE EXTRAAAAA

-- N°20 5 prodotti più redditizi.
SELECT p.Categoria, p.NomeProdotto, 
SUM(Prezzo) AS RicavoTotale
FROM prodotti p
GROUP BY p.Categoria, p.NomeProdotto
ORDER BY RicavoTotale DESC
LIMIT 5;

-- N° 21 Quali prodotti vendono meglio in determinati periodi dell’anno?
SELECT ProdottoID, DATE_FORMAT(DataTransazione, '%Y-%m') AS Mese,
SUM(QuantitaAcquistata) as VenditeTotali
FROM Transazioni
GROUP BY ProdottoID, Mese
ORDER BY VenditeTotali DESC limit 10;

-- N° 22 Categoria con recensioni più alte e categoria con recensioni più basse.
SELECT Categoria, AVG(Rating) AS MediaRecensioni
FROM Prodotti p
JOIN ratings r ON p.ProdottoID = r.ProductID
GROUP BY Categoria
ORDER BY MediaRecensioni DESC, Categoria;

-- N°23 Quali sono i periodi di picco delle vendite? Facciamo un analisi delle vendite per ogni mese
-- Uguale alla N°2 ma in oridne desc
SELECT DATE_FORMAT(DataTransazione, '%Y-%m') AS Mese, SUM(QuantitaAcquistata) as VenditeTotali
FROM Transazioni
GROUP BY Mese
ORDER BY VenditeTotali DESC;

-- N°24 Calcolo del  AVG Totale Spesa.
SELECT AVG(totale_spesa)
FROM (
    SELECT ClienteID, SUM(prodotti.Prezzo * transazioni.QuantitaAcquistata) as totale_spesa
    FROM transazioni 
    JOIN prodotti ON transazioni.ProdottoID = prodotti.ProdottoID
    GROUP BY ClienteID
) as spesa_per_cliente;

-- N°25 Calcolo media della durata di spedizone.
select AVG(DATEDIFF(DataSpedizione, DataTransazione))
AS MediaSpedizione
FROM transazioni;


                                         -- DOMANDE PER IL CONTEST !
--  N°1 Selezione i primi 3 clienti che hanno il prezzo medio di acquisto più alto in ogni categoria di prodotto.
SELECT c.ClienteID, p.Categoria, AVG(t.QuantitaAcquistata * p.Prezzo) AS prezzomedio
FROM transazioni t
JOIN clienti c ON t.ClienteID = c.ClienteID
JOIN prodotti p ON t.ProdottoID = p.ProdottoID
GROUP BY c.ClienteID, p.Categoria
ORDER BY prezzomedio DESC
LIMIT 3;

-- N°2 Quali prodotti vendono meglio in determinati periodi dell’anno?
SELECT ProdottoID, DATE_FORMAT(DataTransazione, '%Y-%m') AS Mese,
SUM(QuantitaAcquistata) as VenditeTotali
FROM Transazioni
GROUP BY ProdottoID, Mese
ORDER BY VenditeTotali DESC limit 10;



